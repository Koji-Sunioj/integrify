import React from 'react';
import ReactDOM from 'react-dom';

import Homepage from './App';

ReactDOM.render(<Homepage />, document.getElementById('root'));
