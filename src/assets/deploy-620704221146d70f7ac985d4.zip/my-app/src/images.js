const images = 
    { id: 1, src: 'shit.png', title: 'foo', description: 'bar' }
  export default images;