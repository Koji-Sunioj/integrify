const images = 
    [
      {tld:'biz',src:'cat.jpg'},
      {tld:'io',src:'cat.jpg'},
      {tld:'me',src:'moose.jpg'},
      {tld:'info',src:'moose.jpg'},
      {tld:'ca',src:'rabbit.jpg'},
      {tld:'org',src:'rabbit.jpg'},
      {tld:'net',src:'giraffe.jpg'},
      {tld:'tv',src:'giraffe.jpg'},


    ]
  export default images;