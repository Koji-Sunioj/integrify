import React from 'react';

    

const Button = () => {
  
return(
        <p> <button className="btn btn-primary link-button">More details</button></p>
       
    );
}
export default Button;